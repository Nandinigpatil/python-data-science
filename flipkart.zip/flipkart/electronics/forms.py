from django import forms
from .models import LaptopModel,MobileModel,TVModel

class LaptopModelForm(forms.ModelForm):
    class Meta:
        model=LaptopModel
        fields = '__all__'

class MobileModelForm(forms.ModelForm):
    class Meta:
        model=MobileModel
        fields = '__all__'

class TVModelForm(forms.ModelForm):
    class Meta:
        model=TVModel
        fields = '__all__'