from django.shortcuts import render
from .forms import LaptopModelForm,MobileModelForm,TVModelForm
# Create your views here.
from .models import LaptopModel
from django.http import HttpResponseRedirect

def Laptop(r):
    form = LaptopModelForm()
    if r.method=='POST':
        form = LaptopModelForm(r.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/index/')

    return render(r,'electronics/laptop.html',{'form':form})

def Mobile(r):
    form = MobileModelForm()
    return render(r,'electronics/mobile.html',{'form':form})

def TV(r):
    form = TVModelForm()
    return render(r,'electronics/tv.html',{'form':form})

def laptopDetails(r):
    laptop_list = LaptopModel.objects.all()
    return render(r,'electronics/laptopdetails.html',{'laptop_list':laptop_list})
